package com.xlei.lf2u.domain;

import static org.junit.Assert.*;

import org.junit.Test;

public class FarmerReportInfoTest {

	@Test
	public void testFarmerReportInfo() {
		FarmerReportInfo report = new FarmerReportInfo();
		assert(report != null);
		
		report.setDeliveryRevenue(0f);
		report.setFid("fid");
		report.setLftuFees(0f);
		report.setName("name");
		report.setOrdersCancelled(0);
		report.setOrdersDelivered(0);
		report.setOrdersOpen(0);
		report.setOrdersPlaced(0);
		report.setPayableToFarm(0f);
		report.setProductsRevenue(0f);
		
		report.getOrdersCancelled();
		report.getOrdersDelivered();
		report.getOrdersOpen();
		report.getOrdersPlaced();
		report.getPayableToFarm();
		report.getProductsRevenue();
		
		assert(report.getDeliveryRevenue() == 0f);
		assertEquals(report.getFid(), "fid");
		assert(report.getLftuFees() == 0f);
		assertEquals(report.getName(), "name");
		
	}

}
