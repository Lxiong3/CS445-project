package com.xlei.lf2u.domain;

import java.util.ArrayList;

import org.junit.Test;

public class FarmerInfoTest {

	@Test
	public void testFarmerInfoString() {
		FarmerInfo farmer = new FarmerInfo("fid");
		assert(farmer != null);
	}

	@Test
	public void testFarmerInfoFarmDetailListOfStringPersonalInfo() {
		FarmerInfo farmer = new FarmerInfo(new FarmDetail(), new ArrayList<String>(),new PersonalInfo());
		assert(farmer != null);
	}

}
