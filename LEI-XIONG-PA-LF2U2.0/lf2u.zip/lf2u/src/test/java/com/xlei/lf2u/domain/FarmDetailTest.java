package com.xlei.lf2u.domain;

import org.junit.Test;

public class FarmDetailTest {

	@Test
	public void testFarmDetail() {
		FarmDetail detail = new FarmDetail();
		assert(detail != null);
	}

	@Test
	public void testSetPhone() {
		FarmDetail detail = new FarmDetail();
		detail.setPhone("131-123-12312");
		assert(detail.getPhone().equals("131-123-12312"));
	}

	@Test
	public void testGetWeb() {
		FarmDetail detail = new FarmDetail();
		detail.setWeb("web");
		assert(detail.getWeb().equals("web"));
	}

	@Test
	public void testSetWeb() {
		FarmDetail detail = new FarmDetail();
		detail.setWeb("web");
		assert(detail.getWeb().equals("web"));
	}

	@Test
	public void testSetAddress() {
		FarmDetail detail = new FarmDetail();
		detail.setAddress("address");
		assert(detail.getAddress().equals("address"));
	}

	@Test
	public void testSetDeliveryCharge() {
		FarmDetail detail = new FarmDetail();
		detail.setAddress("address");
		assert(detail.getAddress().equals("address"));
	}

}
