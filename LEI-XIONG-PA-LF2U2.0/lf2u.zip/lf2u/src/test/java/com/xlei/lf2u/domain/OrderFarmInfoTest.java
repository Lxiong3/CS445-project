package com.xlei.lf2u.domain;

import org.junit.Test;

public class OrderFarmInfoTest {

	@Test
	public void testOrderFarmInfo() {
		OrderFarmInfo info = new OrderFarmInfo();
		info.setAddress("address");
		info.setFid("fid");
		info.setName("name");
		info.setPhone("phone");
		info.setWeb("wen");
		
		info.getAddress();
		info.getFid();
		info.getName();
		info.getPhone();
		info.getWeb();
		
		assert(info != null);
	}

	@Test
	public void testOrderFarmInfoStringStringStringStringString() {
		OrderFarmInfo info = new OrderFarmInfo("123", "123","123","123","123");
		
		assert(info != null);
	}

}
