package com.xlei.lf2u.service;

import java.util.List;

import org.junit.Test;

import com.xlei.lf2u.domain.ManagerInfo;
import com.xlei.lf2u.service.ManagerService;

public class ManagerServiceTest {

	@Test
	public void testManagerService() {
		ManagerService managerService = new ManagerService();
		assert (managerService != null);
	}

	@Test
	public void testGetAllManagers() {
		ManagerService managerService = new ManagerService();
		List<ManagerInfo> allManagers = managerService.getAllManagers();
		assert (allManagers.size() == 1);
	}

	@Test
	public void testFindById() {
		ManagerService managerService = new ManagerService();
		managerService.addManager(new ManagerInfo(null));
		managerService.addManager(new ManagerInfo(null));
		managerService.addManager(new ManagerInfo(null));

		assert (managerService.findById("000") == null);
		assert (managerService.findById("1").getMid().equals("1"));
	}

	@Test
	public void testAdd() {
		ManagerService managerService = new ManagerService();
		managerService.addManager(new ManagerInfo(null));
		managerService.addManager(new ManagerInfo(null));
		managerService.addManager(new ManagerInfo(null));

		assert (managerService.getAllManagers().size() == 4);
	}

}
