package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.config.AppConfig;
import com.xlei.lf2u.config.AppInitializer;
import com.xlei.lf2u.domain.DetailInfo;
import com.xlei.lf2u.domain.FarmDetail;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.OrderInfo;
import com.xlei.lf2u.domain.PersonalInfo;
import com.xlei.lf2u.domain.ProductInfo;
import com.xlei.lf2u.domain.ReportInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { AppConfig.class, AppInitializer.class })
public class ReportServiceTest {

	@Autowired
	ReportService reportService;
	@Autowired
	OrderService orderService;
	@Autowired
	ProductService productSerivce;
	@Autowired
	FarmerService farmerService;
	
	@Test
	public void testReportService() {
		assert(reportService != null);
		
		ProductInfo add = productSerivce.add(new ProductInfo("1", null, "1", "name", null, null, null, 1.0f, "lb", ""));
		farmerService.addFarmer(new FarmerInfo(null, new FarmDetail("1", "dsa", "asda", "dsad"), new PersonalInfo("name", "email", "123"), new ArrayList<String>()));
		OrderInfo order = new OrderInfo();
		DetailInfo detail = new DetailInfo();
		detail.setAmount("1.5");
		detail.setFspid(add.getFspid());
		List<DetailInfo> details = new ArrayList<DetailInfo>();
		details.add(detail);
		order.setOrderDetail(details);
		order.setFid("1");
		order.setStatus("placed");
		
		orderService.addOrder(order);
		
	}

	@Test
	public void testGetReportsByFarmer() {
		ReportService reportService = new ReportService();
		assert(reportService.getFarmerReports().size() == 4);
	}

	@Test
	public void testGetReportDetailByFarmer() {
		ReportInfo report = new ReportInfo();
		assert(reportService.getFarmerReport(report) != null);
		report.setStart_date(new Date());
		report.setEnd_date(Utils.getTomorrowDate(new Date()));
		report.setFrid("1");
		reportService.getFarmerReport(report);
		
		report.setFrid("2");
		reportService.getFarmerReport(report);
		
		report.setFrid("3");
		reportService.getFarmerReport(report);
		
		report.setFrid("4");
		reportService.getFarmerReport(report);
		
		
		
	}

	@Test
	public void testGetReportsByManager() {
		ReportService reportService = new ReportService();
		assert(reportService.getAllManagerReports().size() == 5);
	}

	@Test
	public void testGetReportDetailByManager() {
		ReportInfo report = new ReportInfo();
		assert(reportService.getManagerReport(report) != null);
		
		report.setMrid("1");
		reportService.getManagerReport(report);
		
		report.setMrid("2");
		reportService.getManagerReport(report);
		
		report.setMrid("3");
		reportService.getManagerReport(report);
		
		report.setMrid("4");
		reportService.getManagerReport(report);
		
		report.setMrid("5");
		reportService.getManagerReport(report);
	}

	@Test
	public void testIsContainsFrid() {
		ReportService reportService = new ReportService();
		assert(!reportService.isContainsFrid("000"));
		assert(reportService.isContainsFrid("1"));
	}

	@Test
	public void testIsContainsMrid() {
		ReportService reportService = new ReportService();
		assert(!reportService.isContainsMrid("000"));
		assert(reportService.isContainsMrid("1"));
	}

}
