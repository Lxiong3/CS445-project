package com.xlei.lf2u.domain;

import org.junit.Test;

public class PersonalInfoTest {

	@Test
	public void testPersonalInfo() {
		PersonalInfo info = new PersonalInfo();
		info.setEmail("email");
		info.setName("name");
		info.setPhone("phone");
		
		info.getEmail();
		info.getName();
		info.getPhone();
		
		assert(info != null);
	}

}
