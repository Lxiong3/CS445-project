package com.xlei.lf2u.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.xlei.lf2u.domain.CatalogInfo;
import com.xlei.lf2u.service.CatalogService;

public class CatalogServiceTest {

	@Test
	public void testCatalogService() {
		CatalogService catalogService = new CatalogService();

		assert (catalogService != null);
	}

	@Test
	public void testGetAllCatalogs() {
		CatalogService catalogService = new CatalogService();

		List<CatalogInfo> allCatalogs = catalogService.getAllCatalogs();
		assert (allCatalogs != null);
		assert (allCatalogs.size() == 0);
	}

	@Test
	public void testAdd() {
		CatalogService catalogService = new CatalogService();
		catalogService.addCatalog(new CatalogInfo(null, "name1"));
		catalogService.addCatalog(new CatalogInfo(null, "name2"));
		catalogService.addCatalog(new CatalogInfo(null, "name13"));

		assert (catalogService.getAllCatalogs().size() == 3);
	}

	@Test
	public void testUpdate() {
		CatalogService catalogService = new CatalogService();
		CatalogInfo catalog = catalogService.addCatalog(new CatalogInfo(null, "name1"));

		catalogService.updateCatalog(catalog.getGcpid(), "name2");

		assert(catalogService.getAllCatalogs().get(0).getName().equals("name2"));
		assert(!catalogService.updateCatalog("-1", "dsdas"));
	}
	
	@Test
	public void testFind() {
		CatalogService catalogService = new CatalogService();
		catalogService.addCatalog(new CatalogInfo(null, "name1"));
		catalogService.addCatalog(new CatalogInfo(null, "name2"));
		Assert.assertNull(catalogService.findCatalog("aaa"));
		Assert.assertNotNull(catalogService.findCatalog("1"));
	}

}
