package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.xlei.lf2u.domain.FarmDetail;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.PersonalInfo;

public class FarmerServiceTest{

	
	@Test
	public void testAdd() {
		FarmerService farmerService = new FarmerService();
		List<FarmerInfo> farmers = farmerService.getAllFarmers();
		assert(farmers.size() == 0);
		FarmerInfo farmer = new FarmerInfo("101",new FarmDetail("farm_name", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("30001","30002")));
		farmers.add(farmer);
		assert(farmers.size() == 1);
		assert(farmers.get(0).equals(farmer));
		assert(farmers.get(0).getFid().equals(farmer.getFid()));
	}

	@Test
	public void testUpdate() 
	{
		FarmerService farmerService = new FarmerService();
		FarmerInfo farmer = new FarmerInfo(null,new FarmDetail("farm_name_old", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("30001","30002")));
		FarmerInfo add = farmerService.addFarmer(farmer);
		add.getFarmInfo().setName("farm_name_new");
		add.getPersonalInfo().setName("personal_name_new");
		List<String> delivers_to = add.getDeliversTo();
		delivers_to.add("30003");
		
		farmerService.updateFarmer(add.getFid(), add);
		
		List<FarmerInfo> farmers = farmerService.getAllFarmers();
		assert(farmers.get(farmers.size()-1).getFarmInfo().getName().equals("farm_name_new"));
		assert(farmers.get(farmers.size()-1).getPersonalInfo().getName().equals("personal_name_new"));
		assert(farmers.get(farmers.size()-1).getDeliversTo().size() == 3);
		
		assert(!farmerService.updateFarmer(null,add));
	}

	@Test
	public void testFindById() {
		FarmerService farmerService = new FarmerService();
		farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_1", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("300001","300002"))));
		farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_2", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("300001","300002"))));
		FarmerInfo farmer = farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_3", "847-346-2313", "address","www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("300001","300002"))));
		
		assert(farmer.equals(farmerService.findById(farmer.getFid())));
		assert(farmerService.findById("-1") == null);
		
		
	}

	@Test
	public void testFindByZip() {
		FarmerService farmerService = new FarmerService();
		farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_1", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("300001","300002"))));
		farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_2", "847-346-2313","address", "www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("400001","400002"))));
		farmerService.addFarmer(new FarmerInfo(null,new FarmDetail("farm_name_3", "847-346-2313", "address","www.uuu.com"),new PersonalInfo("personal_name1", "email@e.com", "666-333-1231"),new ArrayList<String>(Arrays.asList("400001","500002"))));

		List<FarmerInfo> farmers = farmerService.findByZip("400001");
		assert(farmers.size() == 2);
		
		farmers = farmerService.findByZip(null);
		assert(farmers.size() == 3);
	}
	
	@Test
	public void testetFarmers() {
		FarmerService farmerService = new FarmerService();
		List<FarmerInfo> farmers = farmerService.getAllFarmers();
		assert(farmers.size() == 0);
	}

}
