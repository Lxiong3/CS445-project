package com.xlei.lf2u.domain;

import org.junit.Test;

public class ProductInfoTest {

	@Test
	public void testProductInfoProductInfo() {
		ProductInfo info = new ProductInfo();
		info.setFid("fid");
		info.setGcpid("fcpid");
		info.setEndDate("");
		ProductInfo info2 = new ProductInfo(info);
		
		assert(info2 != null);
	}

}
