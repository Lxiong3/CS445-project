package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.xlei.lf2u.config.AppConfig;
import com.xlei.lf2u.config.AppInitializer;
import com.xlei.lf2u.domain.DetailInfo;
import com.xlei.lf2u.domain.FarmDetail;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.OrderInfo;
import com.xlei.lf2u.domain.PersonalInfo;
import com.xlei.lf2u.domain.ProductInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { AppConfig.class, AppInitializer.class })
public class OrderServiceTest {

	@Autowired
	OrderService orderService;
	@Autowired
	ProductService productSerivce;
	@Autowired
	FarmerService farmerService;
	
	@Test
	public void testOrderService() {
		OrderService orderService = new OrderService();
		assert(orderService.getAllOrders() != null);
		assert(orderService.getAllOrders().size() == 0);
	}

	@Test
	public void testAdd() {
		ProductInfo add = productSerivce.add(new ProductInfo("1", null, "1", "name", null, null, null, 1.0f, "lb", ""));
		List<OrderInfo> orders = orderService.getAllOrders();
		farmerService.addFarmer(new FarmerInfo(null, new FarmDetail("1", "dsa", "asda", "dsad"), new PersonalInfo("name", "email", "123"), new ArrayList<String>()));
		OrderInfo order = new OrderInfo();
		DetailInfo detail = new DetailInfo();
		detail.setAmount("1.5");
		detail.setFspid(add.getFspid());
		List<DetailInfo> details = new ArrayList<DetailInfo>();
		details.add(detail);
		order.setOrderDetail(details);
		order.setFid("1");
		
		orderService.addOrder(order);
		
		assert(orders.size() >0);
	}

	@Test
	public void testFindByIds() {
		OrderService orderService = new OrderService();
		List<OrderInfo> orders = orderService.getAllOrders();
		
		for(int i=101;i<106;i++) {
			OrderInfo order = new OrderInfo();
			order.setOid(i+"");
			order.setCid((i+100) + "");
			orders.add(order);
		}
		
		assert(orderService.findByIds("000") == null);
		assert(orderService.findByIds("000") == null);
		OrderInfo order = orderService.findByIds("101");
		assert(order.getOid().equals("101"));
		assert(order.getCid().equals("201"));
		
	}

	@Test
	public void testFindByCId() {
		OrderService orderService = new OrderService();
		List<OrderInfo> orders = orderService.getAllOrders();
		
		for(int i=101;i<106;i++) {
			OrderInfo order = new OrderInfo();
			order.setOid(i+"");
			order.setCid("999");
			orders.add(order);
		}
		assert(orderService.findByCId("000").size() == 0);
		assert(orderService.findByCId("999").size() == 5);
	}

	@Test
	public void testCancel() {
		OrderService orderService = new OrderService();
		List<OrderInfo> orders = orderService.getAllOrders();
		
		OrderInfo order = new OrderInfo();
		order.setOid("111");
		order.setCid("999");
		order.setStatus("open");
		orders.add(order);
		
		assert(orderService.findByIds("111").getStatus().equals("open"));
		
		orderService.cancelOrder("999", "111");
		
		assert(orderService.findByIds("111").getStatus().equals("cancelled"));
	}

	@Test
	public void testDeliver() {
		OrderService orderService = new OrderService();
		List<OrderInfo> orders = orderService.getAllOrders();
		
		OrderInfo order = new OrderInfo();
		order.setOid("111");
		order.setCid("999");
		order.setStatus("open");
		orders.add(order);
		
		assert(orderService.findByIds("111").getStatus().equals("open"));
		
		orderService.deliverOrder("111");
		
		assert(orderService.findByIds("111").getStatus().equals("delivered"));
	}
	
	@Test
	public void getOrders() {
		OrderService orderService = new OrderService();
		List<OrderInfo> orders = orderService.getAllOrders();
		
		
		assert(orders.size() == 0);
	}

}
