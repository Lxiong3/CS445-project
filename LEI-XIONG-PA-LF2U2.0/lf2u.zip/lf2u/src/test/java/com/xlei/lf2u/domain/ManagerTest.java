package com.xlei.lf2u.domain;

import java.util.Date;

import org.junit.Test;

public class ManagerTest {

	@Test
	public void testManager() {
		ManagerInfo manager = new ManagerInfo();
		manager.setCreateDate(new Date());
		manager.setCreatedBy("create");
		manager.setEmail("email");
		manager.setMid("mid");
		manager.setName("name");
		manager.setPhone("phone");
		
		manager.getCreateDate();
		manager.getCreatedBy();
		manager.getEmail();
		manager.getMid();
		manager.getName();
		manager.getPhone();
		
		assert(manager != null);
	}

}
