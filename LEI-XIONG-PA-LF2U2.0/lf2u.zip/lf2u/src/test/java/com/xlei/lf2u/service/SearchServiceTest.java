package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.xlei.lf2u.config.AppConfig;
import com.xlei.lf2u.config.AppInitializer;
import com.xlei.lf2u.domain.CustomerInfo;
import com.xlei.lf2u.domain.DetailInfo;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.OrderInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { AppConfig.class, AppInitializer.class })
public class SearchServiceTest {

	@Autowired
	SearchService searchService;

	@Autowired
	OrderService orderService;

	@Autowired
	CustomerService customerService;
	
	@Autowired
	FarmerService farmerService;
	
	
	@Test
	public void testSearchService() {
		assert (searchService != null);
	}

	@Test
	public void testSearch() {
		assert (searchService.search("farm", "key").size() == 0);
		assert (searchService.search("customer", "key").size() == 0);
		assert (searchService.search("order", "key").size() == 0);
		
		farmerService.addFarmer(new FarmerInfo(null, "farmer"));
		
		OrderInfo order = new OrderInfo(null,new Date(),null,null,"placed","1");
		order.setDeliveryNote("note");
		order.setOrderDetail(new ArrayList<DetailInfo>());
		orderService.addOrder(order);
		
		customerService.addCustomer(new CustomerInfo(null, "customer", "street", "600013", "123-456-7890", "email@uu.com"));
		
		assert(searchService.search("xxx", "xxx").size()==0);
		assert(searchService.search("farm", "xxx").size()==0);
		assert(searchService.search("farm", "farmer").size() > 0);
		
		assert(searchService.search("order", "xxx").size()==0);
		assert(searchService.search("order", "note1").size()==0);
		
		assert(searchService.search("customer", "xxx").size()==0);
		assert(searchService.search("customer", "street").size() > 0);
	}

	@Test
	public void testIsContainsTopic() {
		assert (!searchService.isContainsTopic("sdas"));
		assert (searchService.isContainsTopic("order"));
	}
	
}
