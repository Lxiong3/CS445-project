package com.xlei.lf2u.domain;

import org.junit.Test;

public class CatalogInfoTest {

	@Test
	public void testCatalogInfo() {
		CatalogInfo catalog = new CatalogInfo();
		assert(catalog !=null);
	}

	@Test
	public void testCatalogInfoString() {
		CatalogInfo catalog = new CatalogInfo("gcpid");
		assert(catalog !=null);
		assert(catalog.getGcpid().equals("gcpid"));
	}

}
