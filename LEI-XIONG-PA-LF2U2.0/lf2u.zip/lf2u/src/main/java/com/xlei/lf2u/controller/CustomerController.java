package com.xlei.lf2u.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xlei.lf2u.domain.CustomerInfo;
import com.xlei.lf2u.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = {"/customers","/customers/"}, method = RequestMethod.POST)
	public ResponseEntity<CustomerInfo> create(@Valid @RequestBody CustomerInfo customer, BindingResult result) {
		
		if(result.hasErrors()) return new ResponseEntity<CustomerInfo>(HttpStatus.BAD_REQUEST);
		
		customer = customerService.addCustomer(customer);
		CustomerInfo newCustomer = new CustomerInfo(customer.getCid());
		
		return new ResponseEntity<CustomerInfo>(newCustomer,HttpStatus.CREATED) ;
	}

	@RequestMapping(value = {"/customers/{cid}"}, method = RequestMethod.PUT )
	public ResponseEntity<Void> update(@PathVariable("cid") String cid, @Valid @RequestBody CustomerInfo customer, BindingResult result) {
		
		if(customerService.findCustomerById(cid) == null) return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		if(result.hasErrors()) return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		if(customerService.updateCustomer(cid, customer)) return new ResponseEntity<Void>(HttpStatus.OK);
		
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR) ;
	}
	
	@RequestMapping(value = {"/customers/{cid}"}, method = RequestMethod.GET )
	public ResponseEntity<CustomerInfo> findById(@PathVariable("cid") String cid) {
		
		CustomerInfo customer = customerService.findCustomerById(cid);
		if(customer == null) return new ResponseEntity<CustomerInfo>(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<CustomerInfo>(customer,HttpStatus.OK) ;
	}
	
}
