package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.CatalogInfo;

@Service
public class CatalogService {

	private List<CatalogInfo> catalogsList = new ArrayList<CatalogInfo>();
	
	public List<CatalogInfo> getAllCatalogs() {
		return catalogsList;
	}
	
	public CatalogInfo addCatalog(CatalogInfo catalog) {
		String lastId = null;
		if(catalogsList.size() > 0) lastId = catalogsList.get(catalogsList.size()-1).getGcpid();
		String newId = Utils.generateId(lastId);
		catalog.setGcpid(newId);
		
		catalogsList.add(catalog);
		
		return catalog;
	}
	
	public boolean updateCatalog(String gcpid,String name) {
		CatalogInfo findCatalog = findCatalog(gcpid);
		if(findCatalog == null) return false;
		findCatalog.setName(name);
		return true;
	}
	
	public CatalogInfo findCatalog(String gcpid) {
		for (CatalogInfo catalog : catalogsList) {
			if(catalog.getGcpid().equals(gcpid)) {
				return catalog;
			}
		}
		return null;
	}
	
	
}
