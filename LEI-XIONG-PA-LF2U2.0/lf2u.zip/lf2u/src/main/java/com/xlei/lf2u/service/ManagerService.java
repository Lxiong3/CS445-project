package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Service;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.ManagerInfo;

@Service
public class ManagerService {
	private List<ManagerInfo> managersList = new ArrayList<ManagerInfo>();

	public ManagerService() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2016, 10-1, 1);

		managersList.add(
				new ManagerInfo("0", "Super User", "System", calendar.getTime(), "123-0987-654", "superuser@example.com"));
	}

	public ManagerInfo findById(String mid) {
		for (ManagerInfo manager : managersList) {
			if (manager.getMid().equals(mid))
				return manager;
		}
		return null;
	}

	public ManagerInfo addManager(ManagerInfo manager) {
		String lastId = null;
		if (managersList.size() > 0)
			lastId = managersList.get(managersList.size() - 1).getMid();
		String newId = Utils.generateId(lastId);

		manager.setMid(newId);
		managersList.add(manager);

		return manager;
	}
	

	public List<ManagerInfo> getAllManagers() {
		return managersList;
	}

}
