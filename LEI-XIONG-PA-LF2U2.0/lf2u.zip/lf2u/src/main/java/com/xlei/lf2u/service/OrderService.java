	package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.DetailInfo;
import com.xlei.lf2u.domain.OrderFarmInfo;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.OrderInfo;
import com.xlei.lf2u.domain.ProductInfo;

@Service
public class OrderService {

	@Autowired
	ProductService productService;
	@Autowired
	FarmerService farmerService;

	private List<OrderInfo> ordersList = new ArrayList<OrderInfo>();

	public OrderInfo addOrder(OrderInfo order) {
		String lastId = null;
		if (ordersList.size() > 0) lastId = ordersList.get(ordersList.size() - 1).getOid();
		String newId = Utils.generateId(lastId);
		order.setOid(newId);


		Float total = 0f;
		String fid = order.getFid();
		List<DetailInfo> details = order.getOrderDetail();
		for (DetailInfo detail : details) {
			ProductInfo product = productService.findById(fid, detail.getFspid());
			if (product == null)
				continue;
			detail.setName(product.getName());
			detail.setPrice(product.getPrice() + " per " + product.getProductUnit());
			detail.setLineItemTotal(Utils.formatFloat(product.getPrice() * Float.parseFloat(detail.getAmount())));
			detail.setAmount(detail.getAmount() + " " + product.getProductUnit());
			total += detail.getLineItemTotal();
		}
		
		order.setStatus("placed");
		
		order.setOrderDate(new Date());
		order.setPlannedDeliveryDate(Utils.getTomorrowDate(new Date()));
		
		FarmerInfo farmer = farmerService.findById(fid);
		
		OrderFarmInfo farminfo = new OrderFarmInfo(fid, farmer.getFarmInfo());
		order.setOrderFarmInfo(farminfo);
		
		order.setProductsTotal(Utils.formatFloat(total));
		order.setDeliveryCharge(farmer.getFarmInfo().getDeliveryCharge());
		order.setOrderTotal(order.getProductsTotal() + order.getDeliveryCharge());
		
		ordersList.add(order);

		return order;
	}

	public List<OrderInfo> findByCId(String cid) {
		List<OrderInfo> result = new ArrayList<OrderInfo>();
		for (OrderInfo order : ordersList) {
			if (order.getCid().equals(cid))
				result.add(order);
		}
		return result;
	}

	public boolean cancelOrder(String cid, String oid) {
		OrderInfo order = findByIds(oid);
		order.setStatus("cancelled");
		order.setCancelDate(new Date());
		return true;
	}

	public boolean deliverOrder(String oid) {
		OrderInfo order = findByIds(oid);
		order.setStatus("delivered");
		order.setActualDeliveryDate(new Date());
		return true;
	}


	public List<OrderInfo> getAllOrders() {
		return ordersList;
	}

	public OrderInfo findByIds(String oid) {
		for (OrderInfo order : ordersList) {
			if (order.getOid().equals(oid))
				return order;
		}
		return null;
	}

}
