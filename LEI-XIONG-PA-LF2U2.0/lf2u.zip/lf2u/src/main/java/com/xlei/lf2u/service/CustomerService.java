package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.CustomerInfo;

@Service
public class CustomerService {

	private List<CustomerInfo> customersList = new ArrayList<CustomerInfo>();
	
	public CustomerInfo addCustomer(CustomerInfo customer) {
		String lastId = null;
		if(customersList.size() > 0) lastId = customersList.get(customersList.size()-1).getCid();
		String newId = Utils.generateId(lastId);
		
		customer.setCid(newId);
		customersList.add(customer);
		
		return customer;
	}
	
	public boolean updateCustomer(String cid,CustomerInfo newCustomer) {
		CustomerInfo customer = findCustomerById(cid);
		if(customer == null) return false;
		customer.setEmail(newCustomer.getEmail());
		customer.setName(newCustomer.getName());
		customer.setPhone(newCustomer.getPhone());
		customer.setStreet(newCustomer.getStreet());
		customer.setZip(newCustomer.getZip());
		return true;
		
	}
	
	public CustomerInfo findCustomerById(String cid) {
		for (CustomerInfo customer : customersList) {
			if(customer.getCid().equals(cid)) return customer;
		}
		return null;
	}

	public List<CustomerInfo> getAllCustomers() {
		return customersList;
	}
	

}
