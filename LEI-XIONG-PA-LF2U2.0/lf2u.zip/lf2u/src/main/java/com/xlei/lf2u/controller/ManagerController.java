package com.xlei.lf2u.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xlei.lf2u.domain.CatalogInfo;
import com.xlei.lf2u.domain.ManagerInfo;
import com.xlei.lf2u.exception.BadRequestException;
import com.xlei.lf2u.exception.NotFoundException;
import com.xlei.lf2u.service.CatalogService;
import com.xlei.lf2u.service.ManagerService;

@RestController
public class ManagerController {

	@Autowired
	ManagerService managerService = new ManagerService();
	
	@Autowired
	CatalogService catalogService = new CatalogService();
	
	
	@RequestMapping(value = "/managers/accounts/{mid}", method = RequestMethod.GET)
	public ResponseEntity<ManagerInfo> findManagerByid(@PathVariable("mid") String mid) {
		
		ManagerInfo manager = managerService.findById(mid);
		if(manager == null) return new ResponseEntity<ManagerInfo>(HttpStatus.NOT_FOUND) ;
		return new ResponseEntity<ManagerInfo>(manager,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "/managers/accounts", method = RequestMethod.GET)
	public ResponseEntity<List<ManagerInfo>> listAllManagers() {
		
		List<ManagerInfo> allManagers = managerService.getAllManagers();
		
		return new ResponseEntity<List<ManagerInfo>>(allManagers,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "/managers/catalog", method = RequestMethod.GET)
	public ResponseEntity<List<CatalogInfo>> listAllCatalogs() {
		
		List<CatalogInfo> allCatalogs = catalogService.getAllCatalogs();
		
		return new ResponseEntity<List<CatalogInfo>>(allCatalogs,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "/managers/catalog", method = RequestMethod.POST)
	public ResponseEntity<CatalogInfo> createCatalog(@Valid @RequestBody CatalogInfo catalog, BindingResult binding) throws Exception {
		
		if(binding.hasErrors()) throw new BadRequestException();
		
		catalog = catalogService.addCatalog(catalog);
		CatalogInfo newCatalog = new CatalogInfo(catalog.getGcpid());
		return new ResponseEntity<CatalogInfo>(newCatalog,HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/managers/catalog/{gcpid}", method = RequestMethod.POST)
	public ResponseEntity<Void> updateCatalog(@PathVariable("gcpid") String gcpid,@Valid @RequestBody CatalogInfo catalog, BindingResult binding,HttpServletResponse response) throws Exception {
		
		if(binding.hasErrors()) throw new BadRequestException();
		if(!catalogService.updateCatalog(gcpid, catalog.getName())) throw new NotFoundException();
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
