package com.xlei.lf2u.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerAdvice {

    @ExceptionHandler(value=Exception.class)
    public ResponseEntity<Void> exception(Exception exception){
    	ResponseEntity<Void> result = null;
    	if(exception instanceof NotFoundException) {
    		result = new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
    	} else if(exception instanceof NotFoundException) {
    		result = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    	} else if(exception instanceof NoContentException) {
    		result = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    	} else {
    		exception.printStackTrace();
    		result = new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return result;
    }
}
