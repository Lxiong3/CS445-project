package com.xlei.lf2u.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ManagerInfo {

	private String mid;
	private String name;
	@JsonProperty("created_by")
	private String createdBy;
	@DateTimeFormat(pattern="yyyyMMdd")
	@JsonFormat(pattern="yyyyMMdd")
	@JsonProperty("create_date")
	private Date createDate;
	private String phone;
	private String email;

	public ManagerInfo() {
	}
	
	public ManagerInfo(String mid, String name, String createdBy, Date createDate, String phone, String email) {
		this.mid = mid;
		this.name = name;
		this.createdBy = createdBy;
		this.createDate = createDate;
		this.phone = phone;
		this.email = email;
	}

	public ManagerInfo(String mid) {
		this.mid = mid;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
}
