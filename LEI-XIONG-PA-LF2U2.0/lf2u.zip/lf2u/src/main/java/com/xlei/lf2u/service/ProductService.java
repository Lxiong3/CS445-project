package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.CatalogInfo;
import com.xlei.lf2u.domain.ProductInfo;

@Service
public class ProductService {

	@Autowired
	private CatalogService catalogService;

	private List<ProductInfo> productsList = new ArrayList<ProductInfo>();

	public ProductInfo add(ProductInfo product) {
		String lastId = null;
		if (productsList.size() > 0)
			lastId = productsList.get(productsList.size() - 1).getFspid();
		String newId = Utils.generateId(lastId);
		product.setFspid(newId);

		if (catalogService != null) {
			CatalogInfo catalog = catalogService.findCatalog(product.getGcpid());
			if (catalog != null)
				product.setName(catalog.getName());
		}
		productsList.add(product);

		return product;
	}

	public ProductInfo findById(String fid, String fspid) {
		for (ProductInfo product : productsList) {
			if (product.getFid().equals(fid) && product.getFspid().equals(fspid))
				return product;
		}
		return null;
	}

	public List<ProductInfo> findByFid(String fid) {
		List<ProductInfo> result = new ArrayList<ProductInfo>();
		for (ProductInfo product : productsList) {
			if (product.getFid().equals(fid))
				result.add(product);
		}
		return result;

	}

	public boolean update(String fid, String fspid, ProductInfo newProduct) {
		boolean result = false;

		for (ProductInfo product : productsList) {
			if (product.getFid().equals(fid) && product.getFspid().equals(fspid)) {
				if (!StringUtils.isEmpty(newProduct.getNote()))
					product.setNote(newProduct.getNote());
				if (!StringUtils.isEmpty(product.getEndDate())) {
					product.setEndDate(product.getEndDate());
				}
				if (!StringUtils.isEmpty(product.getStartDate())) {
					product.setStartDate(product.getStartDate());
				}
				if (newProduct.getPrice() != null) {
					product.setPrice(newProduct.getPrice());
				}
				if (!StringUtils.isEmpty(newProduct.getProductUnit()))
					product.setProductUnit(newProduct.getProductUnit());
				if (!StringUtils.isEmpty(newProduct.getImage()))
					product.setImage(newProduct.getImage());
				result = true;
			}
		}
		return result;
	}

	public List<ProductInfo> getAllProducts() {
		return productsList;
	}

}
