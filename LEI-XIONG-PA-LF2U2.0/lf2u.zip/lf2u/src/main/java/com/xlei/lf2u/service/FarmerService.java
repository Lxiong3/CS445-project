package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.FarmerInfo;

@Service
public class FarmerService {

	private List<FarmerInfo> farmersList = new ArrayList<FarmerInfo>();
	
	public FarmerInfo addFarmer(FarmerInfo farmer) {
		String lastId = null;
		if(farmersList.size() > 0) lastId = farmersList.get(farmersList.size()-1).getFid();
		String newId = Utils.generateId(lastId);
		
		farmer.setFid(newId);
		farmersList.add(farmer);
		
		return farmer;
	}

	public boolean updateFarmer(String fid,FarmerInfo newFarmer) {
		for (FarmerInfo farmer : farmersList) {
			if(farmer.getFid().equals(fid)) {
				farmer.setDeliversTo(newFarmer.getDeliversTo());
				farmer.setFarmInfo(newFarmer.getFarmInfo());
				farmer.setPersonalInfo(newFarmer.getPersonalInfo());
				return true;
			}
		}
		return false;
	}
	
	public FarmerInfo findById(String fid) {
		for (FarmerInfo farmer : farmersList) {
			if(farmer.getFid().equals(fid)) return farmer;
		}
		return null;
	}
	
	public List<FarmerInfo> findByZip(String zipcode) {
		if(StringUtils.isEmpty(zipcode)){
			return farmersList;
		}
		List<FarmerInfo> result = new ArrayList<FarmerInfo>();
		for (FarmerInfo farmer : farmersList) {
			if(farmer.getDeliversTo().contains(zipcode)){
				result.add(farmer);
			}
		}
		return result;
	}

	public List<FarmerInfo> getAllFarmers() {
		return farmersList;
	}
	

}
