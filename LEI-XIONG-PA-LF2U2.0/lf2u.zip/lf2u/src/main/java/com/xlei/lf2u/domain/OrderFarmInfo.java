package com.xlei.lf2u.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderFarmInfo {

	private String fid;
	private String name;
	private String phone;
	private String address;
	private String web;

	public OrderFarmInfo() {
	}

	public OrderFarmInfo(String fid, String name, String phone, String address,String web) {
		this.fid = fid;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.web = web;
	}

	public OrderFarmInfo(String fid2, FarmDetail farm_info) {
		this.fid = fid2;
		this.name = farm_info.getName();
		this.phone = farm_info.getPhone();
		this.address = farm_info.getAddress();
		this.web = farm_info.getPhone();
	}

	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}


}
