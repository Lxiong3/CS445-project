package com.xlei.lf2u.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xlei.lf2u.domain.ReportInfo;
import com.xlei.lf2u.exception.NotFoundException;
import com.xlei.lf2u.service.FarmerService;
import com.xlei.lf2u.service.ReportService;

@RestController
public class ReportController {

	@Autowired
	private ReportService reportService;
	@Autowired
	private FarmerService farmerService;
	
	@RequestMapping(value = "/farmers/{fid}/reports", method = RequestMethod.GET)
	public ResponseEntity<List<ReportInfo>> getFarmerReports(@PathVariable("fid") String fid) {
		
		return new ResponseEntity<List<ReportInfo>>(reportService.getFarmerReports(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/farmers/{fid}/reports/{frid}", method = RequestMethod.GET)
	public ResponseEntity<ReportInfo> getFarmerReport(@PathVariable("fid") String fid,@PathVariable("frid") String frid, ReportInfo report) throws Exception {
		
		if(farmerService.findById(fid) == null ) throw new NotFoundException();
		
		if(!reportService.isContainsFrid(frid)) throw new NotFoundException();
		
		report.setFrid(frid);
		report = reportService.getFarmerReport(report);
		
		return new ResponseEntity<ReportInfo>(report,HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/managers/reports", method = RequestMethod.GET)
	public ResponseEntity<List<ReportInfo>> getAllManagerReports() {
		
		return new ResponseEntity<List<ReportInfo>>(reportService.getAllManagerReports(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/managers/reports/{mrid}", method = RequestMethod.GET)
	public ResponseEntity<ReportInfo> getManagerReport(@PathVariable("mrid") String mrid,ReportInfo report) throws Exception {
		
		if(!reportService.isContainsMrid(mrid)) throw new NotFoundException();
		
		report.setMrid(mrid);
		report = reportService.getManagerReport(report);
		
		return new ResponseEntity<ReportInfo>(report,HttpStatus.OK);
	}
	
	
	
}
