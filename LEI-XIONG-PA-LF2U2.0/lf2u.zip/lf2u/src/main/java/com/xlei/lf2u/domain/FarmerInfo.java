package com.xlei.lf2u.domain;

import java.util.List;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FarmerInfo {

	private String fid;

	@Valid
	@JsonProperty("farm_info")
	private FarmDetail farmInfo;

	@Valid
	@JsonProperty("personal_info")
	private PersonalInfo personalInfo;

	@NotEmpty
	@JsonProperty("delivers_to")
	private List<String> deliversTo;

	public FarmerInfo() {
	}

	public FarmerInfo(String fid, FarmDetail farmInfo, PersonalInfo personalInfo, List<String> deliversTo) {
		this.fid = fid;
		this.farmInfo = farmInfo;
		this.personalInfo = personalInfo;
		this.deliversTo = deliversTo;
	}

	public FarmerInfo(String fid) {
		this.fid = fid;
	}

	public FarmerInfo(String fid, String name) {
		this.fid = fid;
		this.farmInfo = new FarmDetail(name, null, null, null);
	}

	public FarmerInfo(FarmDetail farmInfo, List<String> deliversTo, PersonalInfo personalInfo) {
		this.farmInfo = farmInfo;
		this.deliversTo = deliversTo;
		this.personalInfo = personalInfo;
	}

	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public FarmDetail getFarmInfo() {
		return farmInfo;
	}

	public void setFarmInfo(FarmDetail farmInfo) {
		this.farmInfo = farmInfo;
	}

	public PersonalInfo getPersonalInfo() {
		return personalInfo;
	}

	public void setPersonalInfo(PersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}

	public List<String> getDeliversTo() {
		return deliversTo;
	}

	public void setDeliversTo(List<String> deliversTo) {
		this.deliversTo = deliversTo;
	}

}
