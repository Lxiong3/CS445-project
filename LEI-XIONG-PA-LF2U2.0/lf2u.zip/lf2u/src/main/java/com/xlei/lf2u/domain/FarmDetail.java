package com.xlei.lf2u.domain;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.xlei.lf2u.common.GlobalConfig;
import com.xlei.lf2u.common.Utils;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FarmDetail {
	
	@NotEmpty
	private String name;
	@NotEmpty
	private String address;
	@NotEmpty
	private String phone;
	private String web;
	
	@JsonIgnore
	@JsonProperty("delivery_charge")
	private Float deliveryCharge = GlobalConfig.INIT_DELIVERY_CHARGE;
	
	public FarmDetail() {
		
	}
	
	public FarmDetail(String name, String phone, String address,String web) {
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.web = web;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Float getDeliveryCharge() {
		return Utils.formatFloat(this.deliveryCharge);
	}

	public void setDeliveryCharge(Float deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	
}
