package com.xlei.lf2u.common;

public class GlobalConfig {

	public final static Float INIT_DELIVERY_CHARGE = 0f;

}
