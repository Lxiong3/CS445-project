package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.OrderInfo;
import com.xlei.lf2u.domain.ReportInfo;

@Service
public class ReportService {

	@Autowired
	OrderService orderService;

	private Map<String, String> farmerReportMap = new HashMap<String, String>();
	private Map<String, String> managerReportMap = new HashMap<String, String>();

	public ReportService() {

		managerReportMap.put("1", "Orders placed today");
		managerReportMap.put("2", "Orders placed yesterday");
		managerReportMap.put("3", "Revenue for previous month");
		managerReportMap.put("4", "Revenue yesterday");
		managerReportMap.put("5", "Revenue yesterday by zip code");
		
		farmerReportMap.put("1", "Orders to deliver today");
		farmerReportMap.put("2", "Orders to deliver tomorrow");
		farmerReportMap.put("3", "Revenue report");
		farmerReportMap.put("4", "Orders delivery report");

	}

	public List<ReportInfo> getFarmerReports() {
		List<ReportInfo> reports = new ArrayList<ReportInfo>();
		for (Map.Entry<String, String> entry : farmerReportMap.entrySet()) {
			reports.add(new ReportInfo(entry.getKey(), entry.getValue()));
		}
		return reports;
	}

	public ReportInfo getFarmerReport(ReportInfo report) {
		String frid = report.getFrid();
		report.setName(farmerReportMap.get(frid));
		if ("1".equals(frid)) {
			report.setOrders(toDeliverOrders(frid, new Date()));
		} else if ("2".equals(frid)) {
			report.setOrders(toDeliverOrders(frid, Utils.getTomorrowDate(new Date())));
		} else if ("3".equals(frid)) {
			report = revenueReport(report);
		} else if ("4".equals(frid)) {
			report.setOrders(deliveredOrders(frid));
		}
		return report;
	}

	public List<OrderInfo> toDeliverOrders(String fid, Date date) {
		List<OrderInfo> orders = orderService.getAllOrders();
		List<OrderInfo> deliverOrders = new ArrayList<OrderInfo>();

		for (OrderInfo order : orders) {
			if (order.getFid().equals(fid)) {
				if (Utils.isSameDay(order.getPlannedDeliveryDate(), date)) {
					deliverOrders.add(order);
				}
			}
		}
		return deliverOrders;
	}

	public List<OrderInfo> deliveredOrders(String fid) {
		List<OrderInfo> orders = orderService.getAllOrders();
		List<OrderInfo> deliverOrders = new ArrayList<OrderInfo>();

		for (OrderInfo order : orders) {
			if (order.getFid().equals(fid)) {
				if ("delivered".equals(order.getStatus()))
					deliverOrders.add(order);
			}
		}
		return deliverOrders;
	}

	public ReportInfo revenueReport(ReportInfo report) {
		Date start = report.getStart_date();
		Date end = report.getEnd_date();
		if (start == null && end == null)
			return report;

		List<OrderInfo> orders = orderService.getAllOrders();

		int placed = 0;
		int cancelled = 0;
		int delivered = 0;
		float products_revenue = 0;
		float delivery_revenue = 0;
		for (OrderInfo order : orders) {
			if (Utils.isBetween(start, end, order.getOrderDate())) {
				if ("placed".equals(order.getStatus()))
					placed += 1;
				if ("canceld".equals(order.getStatus()))
					cancelled += 1;
				if ("delivered".equals(order.getStatus()))
					delivered += 1;
			}
		}
		report.setOrders_cancelled(cancelled);
		report.setOrders_delivered(delivered);
		report.setOrders_placed(placed);
		report.setProducts_revenue(products_revenue);
		report.setDelivery_revenue(delivery_revenue);

		return report;
	}

	public List<ReportInfo> getAllManagerReports() {
		List<ReportInfo> reports = new ArrayList<ReportInfo>();
		for (Map.Entry<String, String> entry : managerReportMap.entrySet()) {
			reports.add(new ReportInfo(entry.getKey(), entry.getValue()));
		}
		return reports;
	}

	public ReportInfo getManagerReport(ReportInfo report) {
		String mrid = report.getMrid();
		report.setName(farmerReportMap.get(mrid));
		if ("1".equals(mrid)) {
		} else if ("2".equals(mrid)) {
		} else if ("3".equals(mrid)) {
		} else if ("4".equals(mrid)) {
		} else if ("5".equals(mrid)) {
		}
		return report;
	}


	public boolean isContainsFrid(String frid) {
		return farmerReportMap.containsKey(frid);
	}

	public boolean isContainsMrid(String mrid) {
		return managerReportMap.containsKey(mrid);
	}

}
