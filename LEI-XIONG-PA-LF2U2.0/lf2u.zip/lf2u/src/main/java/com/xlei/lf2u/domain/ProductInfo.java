package com.xlei.lf2u.domain;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductInfo {
	
	@JsonIgnore
	private String fid;
	private String fspid;
	@NotEmpty
	private String gcpid;
	private String name;
	private String note;
	@JsonProperty("start_date")
	private String startDate;
	@JsonProperty("end_date")
	private String endDate;
	@NotNull
	private Float price;
	@NotEmpty
	@JsonProperty("product_unit")
	private String productUnit;
	private String image;
	
	public ProductInfo() {
	}

	public ProductInfo(String fid, String fspid, String gcpid, String name, String note, String startDate, String endDate,
			Float price, String productUnit, String image) {
		super();
		this.fid = fid;
		this.fspid = fspid;
		this.gcpid = gcpid;
		this.name = name;
		this.note = note;
		this.startDate = startDate;
		this.endDate = endDate;
		this.price = price;
		this.productUnit = productUnit;
		this.image = image;
	}


	public ProductInfo(String fid, String fspid) {
		this.fid = fid;
		this.fspid = fspid;
	}


	public ProductInfo(ProductInfo product) {
		this.fid = product.getFid();
		this.fspid = product.getFspid();
		this.gcpid = product.getGcpid();
		this.name = product.getName();
		this.note = product.getNote();
		this.startDate = product.getStartDate();
		this.endDate = product.getEndDate();
		this.price = product.getPrice();
		this.productUnit = product.getProductUnit();
		this.image = product.getImage();
	}


	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getFspid() {
		return fspid;
	}

	public void setFspid(String fspid) {
		this.fspid = fspid;
	}

	public String getGcpid() {
		return gcpid;
	}

	public void setGcpid(String gcpid) {
		this.gcpid = gcpid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public String getProductUnit() {
		return productUnit;
	}

	public void setProductUnit(String productUnit) {
		this.productUnit = productUnit;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}
