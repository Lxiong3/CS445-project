package com.xlei.lf2u.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xlei.lf2u.domain.OrderInfo;
import com.xlei.lf2u.exception.BadRequestException;
import com.xlei.lf2u.exception.NoContentException;
import com.xlei.lf2u.exception.NotFoundException;
import com.xlei.lf2u.service.CustomerService;
import com.xlei.lf2u.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = "/customers/{cid}/orders", method = RequestMethod.POST)
	public ResponseEntity<OrderInfo> createOrder(@PathVariable String cid,@Valid @RequestBody OrderInfo order, BindingResult binding, HttpServletResponse response) throws Exception {
		
		if(customerService.findCustomerById(cid) == null) throw new NotFoundException();
		
		if(binding.hasErrors()) throw new BadRequestException();
		
		order.setCid(cid);
		order = orderService.addOrder(order);
		OrderInfo newOrder = new OrderInfo(order.getOid());
		
		response.setHeader("Location", String.format("/customers/%s/orders/%s", cid, order.getOid()));
		
		return new ResponseEntity<OrderInfo>(newOrder,HttpStatus.CREATED) ;
	}
	
	@RequestMapping(value = {"/customers/{cid}/orders"}, method = RequestMethod.GET )
	public ResponseEntity<List<OrderInfo>> findOrderByCid(@PathVariable("cid") String cid) throws Exception {
		
		if(customerService.findCustomerById(cid) == null)  throw new NotFoundException();

		List<OrderInfo> result = orderService.findByCId(cid);

		return new ResponseEntity<List<OrderInfo>>(result,HttpStatus.OK);
	}
	
	@RequestMapping(value = {"/customers/{cid}/orders/{oid}"}, method = RequestMethod.GET )
	public ResponseEntity<OrderInfo> findOrderByIds(@PathVariable("cid") String cid,@PathVariable("oid") String oid) throws Exception {
		
		OrderInfo order = orderService.findByIds(oid);
		if(order == null) throw new NotFoundException();
		return new ResponseEntity<OrderInfo>(order,HttpStatus.OK);
	}
	
	@RequestMapping(value = {"/customers/{cid}/orders/{oid}"}, method = RequestMethod.POST )
	public ResponseEntity<Void> cancelOrder(@PathVariable("cid") String cid,@PathVariable("oid") String oid, @RequestBody OrderInfo order,HttpServletResponse response) throws Exception {
		
		if(order==null || StringUtils.isEmpty(order.getStatus())) throw new NoContentException();
		if(!"cancelled".equals(order.getStatus())) throw new BadRequestException();
		
		OrderInfo dbOrder = orderService.findByIds(oid);
		if(dbOrder == null) throw new NotFoundException();
		
		orderService.cancelOrder(cid, oid);
		
		response.setHeader("Location", String.format("/customers/%s/orders/%s", cid, oid));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value = {"/delivery/{oid}"}, method = RequestMethod.POST )
	public ResponseEntity<Void> deliveryOrder(@PathVariable("oid") String oid, @RequestBody OrderInfo order,HttpServletResponse response) throws Exception {
		
		if(order==null || StringUtils.isEmpty(order.getStatus())) throw new NoContentException();
		if(!"delivered".equals(order.getStatus())) throw new BadRequestException();
		
		OrderInfo dbOrder = orderService.findByIds(oid);
		if(dbOrder == null) throw new NotFoundException();
		
		orderService.deliverOrder(oid);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	
}
