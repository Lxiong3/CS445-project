package com.xlei.lf2u.domain;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DetailInfo {

	@NotEmpty
	private String fspid;
	@NotEmpty
	private String amount;

	private String name;

	private String price;

	@JsonProperty("line_item_total")
	private Float lineItemTotal;

	public DetailInfo() {
	}

	public String getFspid() {
		return fspid;
	}

	public void setFspid(String fspid) {
		this.fspid = fspid;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Float getLineItemTotal() {
		return lineItemTotal;
	}

	public void setLineItemTotal(Float lineItemTotal) {
		this.lineItemTotal = lineItemTotal;
	}

}
