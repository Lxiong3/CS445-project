package com.xlei.lf2u.exception;

public class NotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1180949506612781410L;

}
