package com.xlei.lf2u.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FarmerReportInfo {
	
	private String fid;
	
	private String name;
	
	@JsonProperty("orders_placed")
	private Integer ordersPlaced;
	
	@JsonProperty("orders_delivered")
	private Integer ordersDelivered;
	
	@JsonProperty("orders_open")
	private Integer ordersOpen;
	
	@JsonProperty("orders_cancelled")
	private Integer ordersCancelled;
	
	@JsonProperty("products_revenue")
	private Float productsRevenue;
	
	@JsonProperty("delivery_revenue")
	private Float deliveryRevenue;
	
	@JsonProperty("lftu_fees")
	private Float lftuFees;
	
	@JsonProperty("payable_to_farm")
	private Float payableToFarm;
	

	public FarmerReportInfo() {

	}


	public String getFid() {
		return fid;
	}


	public void setFid(String fid) {
		this.fid = fid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Integer getOrdersPlaced() {
		return ordersPlaced;
	}


	public void setOrdersPlaced(Integer ordersPlaced) {
		this.ordersPlaced = ordersPlaced;
	}


	public Integer getOrdersDelivered() {
		return ordersDelivered;
	}


	public void setOrdersDelivered(Integer ordersDelivered) {
		this.ordersDelivered = ordersDelivered;
	}


	public Integer getOrdersOpen() {
		return ordersOpen;
	}


	public void setOrdersOpen(Integer ordersOpen) {
		this.ordersOpen = ordersOpen;
	}


	public Integer getOrdersCancelled() {
		return ordersCancelled;
	}


	public void setOrdersCancelled(Integer ordersCancelled) {
		this.ordersCancelled = ordersCancelled;
	}


	public Float getProductsRevenue() {
		return productsRevenue;
	}


	public void setProductsRevenue(Float productsRevenue) {
		this.productsRevenue = productsRevenue;
	}


	public Float getDeliveryRevenue() {
		return deliveryRevenue;
	}


	public void setDeliveryRevenue(Float deliveryRevenue) {
		this.deliveryRevenue = deliveryRevenue;
	}


	public Float getLftuFees() {
		return lftuFees;
	}


	public void setLftuFees(Float lftuFees) {
		this.lftuFees = lftuFees;
	}


	public Float getPayableToFarm() {
		return payableToFarm;
	}


	public void setPayableToFarm(Float payableToFarm) {
		this.payableToFarm = payableToFarm;
	}


}
