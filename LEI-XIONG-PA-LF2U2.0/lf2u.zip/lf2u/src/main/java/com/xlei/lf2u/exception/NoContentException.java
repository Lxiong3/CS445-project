package com.xlei.lf2u.exception;

public class NoContentException extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5627550641362621838L;

}
