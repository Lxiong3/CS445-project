package com.xlei.lf2u.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.CustomerInfo;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.OrderInfo;

@Service
public class SearchService {
	
	@Autowired
	private FarmerService farmerService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private OrderService orderService;
	
	private List<String> topics = new ArrayList<String>(Arrays.asList("order","customer","farm"));
	
	public List<?> search(String topic,String keyword) {
		List<Object> result = new ArrayList<Object>();
		if("farm".equals(topic)){
			if(StringUtils.isEmpty(keyword)) return farmerService.getAllFarmers();
			List<FarmerInfo> farmers = farmerService.getAllFarmers();
			for (FarmerInfo farmer : farmers) {
				if(Utils.containKeyword(farmer, keyword)) result.add(farmer);
			}
		} else if("customer".equals(topic)){
			if(StringUtils.isEmpty(keyword)) return customerService.getAllCustomers();
			List<CustomerInfo> customers = customerService.getAllCustomers();
			for (CustomerInfo customer : customers) {
				if(Utils.containKeyword(customer, keyword)) result.add(customer);
			}
		} else if("order".equals(topic)){
			if(StringUtils.isEmpty(keyword)) return orderService.getAllOrders();
			List<OrderInfo> orders = orderService.getAllOrders();
			for (OrderInfo order : orders) {
				if(Utils.containKeyword(order, keyword)) result.add(order);
			}
		} 
		return result;
	}
	
	public boolean isContainsTopic(String topic){
		return topics.contains(topic.toLowerCase());
	}
}
