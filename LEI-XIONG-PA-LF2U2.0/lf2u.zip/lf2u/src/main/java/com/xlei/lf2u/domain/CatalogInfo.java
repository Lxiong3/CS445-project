package com.xlei.lf2u.domain;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CatalogInfo {

	private String gcpid;
	@NotEmpty
	private String name;
	
	public CatalogInfo() {

	}

	public CatalogInfo(String gcpid, String name) {
		this.gcpid = gcpid;
		this.name = name;
	}

	public CatalogInfo(String gcpid2) {
		this.gcpid = gcpid2;
	}

	public String getGcpid() {
		return gcpid;
	}

	public void setGcpid(String gcpid) {
		this.gcpid = gcpid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
