package com.xlei.lf2u.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xlei.lf2u.common.Utils;
import com.xlei.lf2u.domain.OrderFarmInfo;
import com.xlei.lf2u.domain.FarmerInfo;
import com.xlei.lf2u.domain.ProductInfo;
import com.xlei.lf2u.exception.BadRequestException;
import com.xlei.lf2u.exception.NoContentException;
import com.xlei.lf2u.exception.NotFoundException;
import com.xlei.lf2u.service.FarmerService;
import com.xlei.lf2u.service.ProductService;

@RestController
public class FarmerController {
	
	@Autowired
	FarmerService farmerService;
	
	@Autowired
	ProductService productService;

	@RequestMapping(value = {"/farmers","/farmers/"}, method = RequestMethod.POST)
	public ResponseEntity<FarmerInfo> createFarmer(@Valid @RequestBody FarmerInfo farmer, BindingResult binding) throws Exception {
		
		if(binding.hasErrors()) throw new BadRequestException();
		
		farmer = farmerService.addFarmer(farmer);
		FarmerInfo newFarmer = new FarmerInfo(farmer.getFid());
		
		return new ResponseEntity<FarmerInfo>(newFarmer,HttpStatus.CREATED) ;
	}
	
	@RequestMapping(value = {"/farmers/{fid}"}, method = RequestMethod.PUT )
	public ResponseEntity<Void> update(@PathVariable("fid") String fid, @Valid @RequestBody FarmerInfo farmer, BindingResult binding) throws Exception {
		
		if(farmerService.findById(fid) == null) throw new NotFoundException();
		if(binding.hasErrors()) throw new BadRequestException();
		if(farmerService.updateFarmer(fid,farmer)) return new ResponseEntity<Void>(HttpStatus.OK);
		
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR) ;
	}
	
	@RequestMapping(value = "/farmers/{fid}", method = RequestMethod.GET)
	public ResponseEntity<FarmerInfo> view(@PathVariable("fid") String fid) throws NotFoundException {
		
		FarmerInfo farmer = farmerService.findById(fid);
		if(farmer == null) throw new NotFoundException();
		
		FarmerInfo result = new FarmerInfo(farmer.getFarmInfo(), farmer.getDeliversTo(), farmer.getPersonalInfo());
		return new ResponseEntity<FarmerInfo>(result,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = {"/farmers/","/farmers"}, method = RequestMethod.GET)
	public ResponseEntity<List<OrderFarmInfo>> searchFarmersByZip(String zip) {
		
		List<FarmerInfo> findByZip = farmerService.findByZip(zip);
		List<OrderFarmInfo> result = new ArrayList<OrderFarmInfo>();
		for (FarmerInfo farmer : findByZip) {
			result.add(new OrderFarmInfo(farmer.getFid(),farmer.getFarmInfo().getName(),null,null,null));
		}
		
		return new ResponseEntity<List<OrderFarmInfo>>(result,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "farmers/{fid}/delivery_charge", method = RequestMethod.GET)
	public ResponseEntity<Map<String,Float>> getDeliveryChargeByFid(@PathVariable String fid) throws Exception {
		
		FarmerInfo farmer = farmerService.findById(fid);
		if(farmer == null) throw new NotFoundException();
		
		Map<String,Float> result = new HashMap<String, Float>();
		result.put("delivery_charge", Utils.formatFloat(farmer.getFarmInfo().getDeliveryCharge()));
		return new ResponseEntity<Map<String,Float>>(result,HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "farmers/{fid}/delivery_charge", method = RequestMethod.POST)
	public ResponseEntity<Void> setDeliveryCharge(@PathVariable String fid,@RequestBody Map<String,Float> params, HttpServletResponse response) throws Exception {
		
		if(params.get("delivery_charge") == null ) throw new NoContentException();
		if(params.get("delivery_charge") < 0 ) throw new BadRequestException();
		
		
		FarmerInfo farmer = farmerService.findById(fid);
		if(farmer == null) throw new NotFoundException();
		
		farmer.getFarmInfo().setDeliveryCharge(Utils.formatFloat(params.get("delivery_charge")));
		
		String location = String.format("/admin/%s/delivery_charge", fid);

		response.setHeader("Location", location);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/farmers/{fid}/products", method = RequestMethod.GET)
	public ResponseEntity<List<ProductInfo>> listProductsByFid(@PathVariable("fid") String fid) throws Exception {
		
		FarmerInfo farmer = farmerService.findById(fid);
		if(farmer == null) throw new NotFoundException();
		List<ProductInfo> products = productService.findByFid(fid);
		return new ResponseEntity<List<ProductInfo>>(products,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/farmers/{fid}/products", method = RequestMethod.POST)
	public ResponseEntity<ProductInfo> createProduct(@PathVariable("fid") String fid, @Valid @RequestBody ProductInfo product, BindingResult bingding,HttpServletResponse response) throws Exception {
		
		if(bingding.hasErrors()) throw new BadRequestException();
		
		FarmerInfo farmer = farmerService.findById(fid);
		if(farmer == null) throw new NotFoundException();
		
		product.setFid(fid);
		ProductInfo addProduct = productService.add(product);
		String location = String.format("/farmers/%s/products/%s", fid, addProduct.getFspid());
		response.setHeader("Location", location);
		
		ProductInfo resultProduct = new ProductInfo(addProduct.getFid(),addProduct.getFspid());
		return new ResponseEntity<ProductInfo>(resultProduct,HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/farmers/{fid}/products/{fspid}", method = RequestMethod.POST)
	public ResponseEntity<Void> updateProduct(@PathVariable("fid") String fid,@PathVariable("fspid") String fspid, @RequestBody ProductInfo product, HttpServletResponse response) throws Exception {
		
		ProductInfo dbProduct = productService.findById(fid,fspid);
		if(dbProduct == null) throw new NotFoundException();
		
		if(productService.update(fid, fspid, product)) {
			String location = String.format("/farmers/%s/products/%s", fid, fspid);
			response.setHeader("Location", location);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		throw new Exception();
	}
	
	@RequestMapping(value = "/farmers/{fid}/products/{fspid}", method = RequestMethod.GET)
	public ResponseEntity<ProductInfo> findProductById(@PathVariable("fid") String fid,@PathVariable("fspid") String fspid,HttpServletResponse response) throws NotFoundException {
		
		ProductInfo dbProduct = productService.findById(fid,fspid);
		if(dbProduct == null) throw new NotFoundException();
		
		ProductInfo product = new ProductInfo(dbProduct);
		product.setGcpid(null);
		return new ResponseEntity<ProductInfo>(product,HttpStatus.OK);
	}
	
}
