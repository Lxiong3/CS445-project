package com.xlei.lf2u.exception;

public class BadRequestException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2283827153030397837L;

}
