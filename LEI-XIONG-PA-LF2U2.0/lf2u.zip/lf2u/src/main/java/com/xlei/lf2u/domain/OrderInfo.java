package com.xlei.lf2u.domain;

import java.util.Date;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderInfo {
	
	private String oid;
	@NotEmpty
	private String fid;
	
	private String cid;
	
	@JsonProperty("order_date")
	@JsonFormat(pattern="yyyyMMdd")
	private Date orderDate;
	
	@JsonProperty("planned_delivery_date")
	@JsonFormat(pattern="yyyyMMdd")
	private Date plannedDeliveryDate;
	
	@JsonProperty("actual_delivery_date")
	@JsonFormat(pattern="yyyyMMdd")
	private Date actualDeliveryDate;
	
	@JsonProperty("cancel_date")
	@JsonFormat(pattern="yyyyMMdd")
	private Date cancelDate;
	
	private String status;
	
	@NotEmpty
	@JsonProperty("order_detail")
	private List<DetailInfo> orderDetail;
	
	@JsonProperty("delivery_note")
	private String deliveryNote;
	
	@JsonProperty("products_total")
	private Float productsTotal;
	
	@JsonProperty("delivery_charge")
	private Float deliveryCharge;
	
	@JsonProperty("order_total")
	private Float orderTotal;
	
	@JsonProperty("farm_info")
	private OrderFarmInfo orderFarmInfo;
	
	public OrderInfo() {
		
	}

	public OrderInfo(String oid) {
		this.oid = oid;
	}

	public OrderInfo(String oid, Date orderDate, Date plannedDeliveryDate, Date actualDeliveryDate, String status,
			String fid) {
		this.oid = oid;
		this.orderDate = orderDate;
		this.plannedDeliveryDate = plannedDeliveryDate;
		this.actualDeliveryDate = actualDeliveryDate;
		this.status = status;
		this.fid = fid;
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getPlannedDeliveryDate() {
		return plannedDeliveryDate;
	}

	public void setPlannedDeliveryDate(Date plannedDeliveryDate) {
		this.plannedDeliveryDate = plannedDeliveryDate;
	}

	public Date getActualDeliveryDate() {
		return actualDeliveryDate;
	}

	public void setActualDeliveryDate(Date actualDeliveryDate) {
		this.actualDeliveryDate = actualDeliveryDate;
	}

	public Date getCancelDate() {
		return cancelDate;
	}

	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DetailInfo> getOrderDetail() {
		return orderDetail;
	}

	public void setOrderDetail(List<DetailInfo> orderDetail) {
		this.orderDetail = orderDetail;
	}

	public String getDeliveryNote() {
		return deliveryNote;
	}

	public void setDeliveryNote(String deliveryNote) {
		this.deliveryNote = deliveryNote;
	}

	public Float getProductsTotal() {
		return productsTotal;
	}

	public void setProductsTotal(Float productsTotal) {
		this.productsTotal = productsTotal;
	}

	public Float getDeliveryCharge() {
		return deliveryCharge;
	}

	public void setDeliveryCharge(Float deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}

	public Float getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(Float orderTotal) {
		this.orderTotal = orderTotal;
	}

	public OrderFarmInfo getOrderFarmInfo() {
		return orderFarmInfo;
	}

	public void setOrderFarmInfo(OrderFarmInfo orderFarmInfo) {
		this.orderFarmInfo = orderFarmInfo;
	}



}
